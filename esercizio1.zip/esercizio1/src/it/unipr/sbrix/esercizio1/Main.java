package it.unipr.sbrix.esercizio1;

import java.io.IOException;

public class Main {
	 

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Agenzia agenzia = new Agenzia();
		
		agenzia.gestioneMenu();
		
		agenzia.consoleInput.close();

	}

}
